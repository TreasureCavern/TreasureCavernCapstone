﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour {
	enum FacingState {
	    left,
	    right
	}
	FacingState facing = FacingState.right;
	enum AnimState {
		idle,
		moving,
		shooting
	}
	AnimState state = AnimState.idle;
	private Rigidbody2D myRigidbody;

	public int health;
	int maxHealth;
	int moveSpeed;


	float offset = 0.0f;

	void Start () {
		tag = "Player";
		health = 3;
		maxHealth = health;
		moveSpeed = 5;
		myRigidbody = GetComponent<Rigidbody2D>();
	}

	// Update is called once per frame
	void FixedUpdate () {
		float xForce = Input.GetAxisRaw ("Horizontal");
		float yForce = Input.GetAxisRaw ("Vertical");
		if (xForce != 0 || yForce != 0) {
			Vector2 movingVector = new Vector2 (xForce*moveSpeed, yForce*moveSpeed);
			myRigidbody.AddForce (movingVector);
		} else {
			myRigidbody.velocity = new Vector2 (0, 0);
		}
		FaceMouse ();
		ControlCamera ();
		if (health <= 0) {
			float timeUntilQuit = 5f;
			Debug.Log ("You Died...");
			Destroy (gameObject);
			Application.Quit ();
			//Debug.Log ("-Quit-");		
		}
	}
	void FaceMouse(){
		Vector3 mousePosition = Input.mousePosition;
		mousePosition = Camera.main.ScreenToWorldPoint (mousePosition);
		Vector2 direction = new Vector2 (mousePosition.x - transform.position.x, mousePosition.y - transform.position.y);
		transform.up = direction;
	}
	void ControlCamera(){
		Camera main = Camera.main;
		main.transform.position = new Vector3(transform.position.x,transform.position.y, -3);
	}
	/*Function to set animator states, passing in movement x and y
	private void GetFace (float x, float y) {
	    if  (x > 0){
	        facing = FacingState.right;
	    }
	    else if (x < 0){
	        facing = FacingState.left;
	    }
	    else if (y > 0){
	        facing = FacingState.up;
	    }
	    else if (y < 0){
	        facing = FacingState.down;
	    }
	}*/
	void OnTriggerEnter2D(Collider2D col){
		//Create new level
		if (col.gameObject.tag == "Door") {
			SceneManager.LoadScene (SceneManager.GetActiveScene ().name);
		} 
		if (col.gameObject.tag == "Health") {
			int heal = 0;
			HealthPickup healPickup = col.gameObject.GetComponent<HealthPickup> ();
			if (health < maxHealth) {
				heal = healPickup.PickupHealth (out heal);
				Destroy (healPickup.gameObject);
				health += heal;
			}
		}
	}
}
