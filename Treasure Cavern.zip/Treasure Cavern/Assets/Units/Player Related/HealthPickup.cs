﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthPickup : MonoBehaviour {

	public int PickupHealth(out int heal){
		Debug.Log ("Health + 1");
		heal = 1;
		return heal;
	}

}
