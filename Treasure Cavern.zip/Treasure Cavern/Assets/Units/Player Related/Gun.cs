﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour {
	protected GameObject gProjectileObj;	//Projectile that will be shot
	protected string gGunName;			//Name of the gun
	protected float gFiringTimer;		//Time until you can fire again
	protected float gFireRate;			//Time after firing you must wait to fire again
	protected float gReloadTime;		//Time it takes to reload
	protected bool gReloading;			//Whether the gun is currently being reloaded
	protected int gMaxAmmo;				//Maximum ammo the gun can hold at any point
	protected int gAmmo;				//Current ammo held in the gun
	protected FiringModes gFiringMode;	//The gun's current firing mode

	//List of possible firing modes
	public enum FiringModes {
		Auto,
		semiAuto
	};

	protected virtual void Start() {
		gProjectileObj = Resources.Load ("Prefabs/Projectile") as GameObject;
		gGunName = "Gun";
		gFiringTimer = 0f;
		gFireRate = 1f;
		gReloadTime = 1f;
		gReloading = false;
		gMaxAmmo = 1;
		gAmmo = gMaxAmmo;
		gFiringMode = FiringModes.semiAuto;
        
    }

	//Controls shooting and relaoding the gun
	public void GunController () {
		//Removes the change in time from gFiringTimer
		gFiringTimer -= Time.deltaTime;

		//Fires the gun in semi-automatic or automatic, depending on gFiringMode
		if (gFiringMode == FiringModes.semiAuto && Input.GetKeyDown (KeyCode.Mouse0)) {
			Shoot ();
		} else if (gFiringMode == FiringModes.Auto && Input.GetKey (KeyCode.Mouse0)) {
			Shoot ();
		}

		//Reloads the gun if the reload key is pressed and you are not
		//already reloading
		if (gAmmo <= 0 && gReloading == false) {
			StartCoroutine (Reload ());
		}
	}

	//Creates an instance of gProjectileObj if there is ammo left in the gun,
	//the gun is not currently being reloaded, and you have not shot the gun
	//within gFireRate seconds
	protected void Shoot (){
		if (gAmmo > 0 && gReloading == false && gFiringTimer <= 0) {
			GameObject projectileObj = Instantiate (gProjectileObj);
			projectileObj.tag = "PlayerProjectile";
			projectileObj.transform.position = transform.position;
			projectileObj.transform.rotation = transform.rotation;
			//Ignores collisions between the projectile and the object that fired it
			Physics2D.IgnoreCollision (projectileObj.GetComponent<Collider2D> (), GetComponent<Collider2D> ());

			gFiringTimer = gFireRate;
			gAmmo -= 1;
			//Debug.Log (gAmmo);
		}
	}

	protected IEnumerator Reload (){
		//Debug.Log ("Reloading");
		gReloading = true;
		yield return new WaitForSeconds (gReloadTime);
		gAmmo = gMaxAmmo;
		gReloading = false;
		//Debug.Log ("Done Reloading");
	}
}

	
