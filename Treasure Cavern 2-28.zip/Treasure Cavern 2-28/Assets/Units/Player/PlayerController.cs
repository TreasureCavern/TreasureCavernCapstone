﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {
	float xInput = 0, yInput = 0, speed = 5;
	bool mouseLeft, canShoot;
	float lastShot = 0, timeBetweenShots = 0.25f;
	Vector3 mousePos, mouseVector;
	public Transform gunSprite, gunTip;
	public SpriteRenderer gunRend;
	public GameObject bulletPrefab;
	public CameraController Cam;
	public int health;
	int maxHealth;
	bool isDead;

	enum AnimState {
		idle,
		moving,
		shooting
	}

	AnimState state = AnimState.idle;
	private Rigidbody2D myRigidbody;
	private Animator anim;

	void Start () {
		health = 3;
		maxHealth = health;
		isDead = false;
		GetMouseInput();
		Cam = FindObjectOfType<CameraController>();
		anim = GetComponent<Animator>();
		if (gunRend == null) {gunRend = GameObject.FindGameObjectWithTag ("Gun").GetComponentInChildren<SpriteRenderer> ();}
		if (gunSprite == null) {gunSprite = GameObject.FindGameObjectWithTag ("Gun").transform;}
		if (gunTip == null) {gunTip = GameObject.FindGameObjectWithTag ("Gun").GetComponentInChildren<Transform>();}
	}

	void Update () {
		while (isDead == false) {
			GetInput (); //capture wasd and mouse
			Movement (); //move the player
			Animation (); //rotate the gun
			Shooting (); //handle shooting
			anim.SetFloat ("MoveX", Input.GetAxisRaw ("Horizontal"));
			anim.SetFloat ("MoveY", Input.GetAxisRaw ("Vertical"));

			if (health <= 0) {
				isDead = true;
				Destroy (gameObject);
				Application.Quit ();
			}
		}
	}
	void GetInput(){
		xInput = Input.GetAxis("Horizontal"); 
		yInput = Input.GetAxis("Vertical");																			// Capture WASD keys
		GetMouseInput();																							// Capture current mouse position
	}
	void GetMouseInput(){
		mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition); 											// Position of cursor in world
		mousePos.z = transform.position.z; 																			// Keep the z position consistant, since we're in 2d
		mouseVector = (mousePos - transform.position).normalized; 													// Normalized vector from player pointing to cursor
		mouseLeft = Input.GetMouseButton(0); 																		// Check whether the left mouse button is pressed (Fire Weapon)
	}
	void Movement(){
		Vector3 tempPos = transform.position;
		tempPos += new Vector3(xInput,yInput,0) * speed * Time.deltaTime; 											// Move the player based on horizontal and vertical inputs (WASD keys)
		transform.position = tempPos;
	}
	void Animation(){
		float gunAngle = -1 * Mathf.Atan2(mouseVector.y, mouseVector.x) * Mathf.Rad2Deg; 							// Find angle in degrees from player to cursor
		gunSprite.rotation = Quaternion.AngleAxis(gunAngle, Vector3.back); 											// Rotate gun sprite around that angle ^
		if (Mathf.Sign(mouseVector.x) == -1 && gunRend.flipY == false) {
			gunRend.flipY = true;
		}
		else if(Mathf.Sign(mouseVector.x) == 1 && gunRend.flipY == true) {
			gunRend.flipY = false;
		}
	}
	void Shooting()	{
		canShoot = (lastShot + timeBetweenShots < Time.time);
		if (mouseLeft && canShoot){ 																				// Fire if the mouse button is held and its been enough time since last shot
			Vector3 spawnPos = gunTip.position; 																	// Position of the tip of the gun, a transform that is a child of rotating gun
			Quaternion spawnRot = Quaternion.identity; 																// No rotation, bullets here are round
			Bullet bul = Instantiate(bulletPrefab, spawnPos, spawnRot).GetComponent<Bullet>();						// Spawn bullet and capture it's script
			bul.Setup(mouseVector); 																				// Give the bullet a direction to fly
			lastShot = Time.time; 																					// Captures time of most recent shot fired
			Cam.Shake((transform.position - gunTip.position).normalized, 3f, 0.05f); 								// Call main camera's shake function for recoil
		}
	}
}

