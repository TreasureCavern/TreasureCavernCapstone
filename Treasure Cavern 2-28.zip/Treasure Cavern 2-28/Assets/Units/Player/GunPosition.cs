﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunPosition : MonoBehaviour {
	public Transform AttachedTo; // The position information of the player this weapon will be attached to.

	void Start(){
		AttachedTo = GameObject.FindObjectOfType<PlayerController> ().transform;
	}

	void LateUpdate () {
		gameObject.transform.position = AttachedTo.position; // Sets the position of the weapon relative to the player, every step of runtime.
	}
}
