﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthSpawner : MonoBehaviour {
	//This is the code for the enemy spawner repurposed as a health pickup spawner
	//The spawner will not create a new HPU until the own it is holding gets picked up.
	public HealthPickup healthPickup;
	float gSpawnRate = 10f;
	float gTimer = 10f;
	HealthPickup HPU = null; 

	// Update is called once per frame
	void FixedUpdate () {
		gTimer -= Time.deltaTime;

		if (gTimer <= 0 && HPU == null) {					
			HPU = Instantiate (healthPickup, transform);
			gTimer = gSpawnRate;
		}
	}
}
