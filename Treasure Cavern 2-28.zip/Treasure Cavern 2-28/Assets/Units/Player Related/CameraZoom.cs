﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraZoom : MonoBehaviour {
	//The desired projection size
	public float TargetOrtho;
	//Speed of zooming the camera
	public float ZoomSpeed = 5;
	//How fast the current projection size should change to the
	//target projection size
	public float SmoothSpeed = 20.0f;
	//Minimum projection size
	public float MinOrtho = 1.0f;
	//Maximum projection size
	public float MaxOrtho = 25.0f;

	// Use this for initialization
	void Start () {
		//Grabs the camera's current projection size
		TargetOrtho = Camera.main.orthographicSize;
	}

	// Update is called once per frame
	void Update () {
		//Gets how fast the scroll wheel is being scrolled,
		//and in what direction
		float scroll = Input.GetAxis ("Mouse ScrollWheel");

		//Checks if the scroll wheel is being scrolled
		if (scroll != 0.0f) {
			//Changes the target projection size
			TargetOrtho -= scroll * ZoomSpeed;
			//Keeps target ortho between MinOrtho and MaxOrtho
			TargetOrtho = Mathf.Clamp (TargetOrtho, MinOrtho, MaxOrtho);
		}

		//Changes the projection size of the camera
		Camera.main.orthographicSize = Mathf.MoveTowards (Camera.main.orthographicSize,
			TargetOrtho, SmoothSpeed * Time.deltaTime);
	}
}
