﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shoot : MonoBehaviour {
	public Rigidbody2D projectile;
	public Transform projectileSpawnPoint;
	public float projectileVelocity;
	public float timeBetweenShots;

	private float timeBetweenShotsCounter;
	private bool canShoot;

	void Start(){
		canShoot = false;
		timeBetweenShotsCounter = timeBetweenShots;
	}
	void Update(){
		if (Input.GetMouseButtonDown (0) && canShoot) {
			Rigidbody2D bulletInstance = Instantiate (projectile, projectileSpawnPoint.position, Quaternion.Euler (new Vector3 (0, 0, transform.localEulerAngles.z)))as Rigidbody2D;
			bulletInstance.GetComponent<Rigidbody2D> ().AddForce (projectileSpawnPoint.up * projectileVelocity);
			canShoot = false;
		}
		if (!canShoot) {
			timeBetweenShotsCounter -= Time.deltaTime;
			if (timeBetweenShotsCounter <= 0) {
				canShoot = true;
				timeBetweenShotsCounter = timeBetweenShots;
			}
		}
	}
}
