﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour {
	public float gMovementSpeed = 1f;	//Movement speed of the projectile
	public int gDamage = 1;				//Damage the projectile deals upon collision
	float gTimeUntilDestroy = 5f;		//Time until the projectile destroys itself

	void FixedUpdate () {
		//Moves the projectile
		Move ();

		gTimeUntilDestroy -= Time.deltaTime;
		if (gTimeUntilDestroy <= 0) {
			Destroy (gameObject);
		}
	}

	void OnCollisionEnter2D (Collision2D col) {
		if (col.gameObject.tag == "Wall" || col.gameObject.tag == "Door") {
			Hit ();
		}
	}

	//Moves the projectile
	protected void Move () {
		//Moves the projectile forward, dependnt on the projectile's rotation
		transform.Translate (new Vector3 (0, 1) * Time.deltaTime * gMovementSpeed);
	}

	//Called when the projectile collides with an enemy
	public void Hit () {
		
		Destroy (gameObject);
	}
}