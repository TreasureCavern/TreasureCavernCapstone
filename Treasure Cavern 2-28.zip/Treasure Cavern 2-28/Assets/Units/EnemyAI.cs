﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI : MonoBehaviour {
	public GameObject Target;
	public float Speed;
	public float chaseRange = .5f;
	public float timeBetweenMoveCounter;
	public int health;
	private float timeToMoveCounter;
	private Rigidbody2D RB2D;
	private bool moving = false;
	private float timeBetweenMove;
	private float timeToMove;
	private Vector3 moveDirection;

	// Use this for initialization
	void Start () {
		Target  = GameObject.FindGameObjectWithTag("Player").gameObject;
		Speed = 3;
		RB2D = gameObject.GetComponent<Rigidbody2D> ();
		timeBetweenMoveCounter = timeBetweenMove;
		timeToMoveCounter = timeToMove;
		health = 3;
	}

	// Update is called once per frame
	void Update () {
		if (moving) {
			if (Vector3.Distance (Target.transform.position, this.transform.position) < chaseRange) {
				Vector3 dir = Target.transform.position - this.transform.position;
				dir.Normalize ();
				this.transform.position += dir * Speed * Time.deltaTime;
			}
		} else {
			timeBetweenMoveCounter -= Time.deltaTime;
			if (timeBetweenMoveCounter < 0f) {
				moving = true;
				timeToMoveCounter = timeToMove;
			}
		}
		if (health <= 0) { 
			Destroy (gameObject);
		}
	}
	void OnCollisionEnter2D(Collision2D coll){
		if (coll.gameObject.tag == "Player") {
			Target.GetComponent<PlayerController> ().health -= 1;
			Debug.Log ("HIT");
		}
		if (coll.gameObject.tag == "Projectile") {
			this.health -= 1;
			Debug.Log ("HIT LANDED");
			coll.gameObject.GetComponent<Projectile> ().Hit ();

		}


	}
}
